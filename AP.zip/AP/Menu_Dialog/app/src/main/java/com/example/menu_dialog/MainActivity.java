package com.example.menu_dialog;

import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.os.Bundle;
import androidx.activity.R;
import androidx.appcompat.app.*;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button showDialogButton = findViewById(R.id.button_show_dialog);
        showDialogButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                showCustomDialog();
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.action_settings:
                Toast.makeText(this,"Settings clicked",Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_about:
                Toast.makeText(this,"About clicked",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void showCustomDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Custom Dialog")
                .setMessage("This is a custom dialog")
                .setPositiveButton("OK",(dialog,which) -> dialog.dismiss())
                .setNegativeButton("Cancel",(dialog,which) -> dialog.dismiss())
                .create()
                .show();
    }
}
