package com.example.menu_dialog;

import android.app.Activity;

public class menu_example extends Activity {
}
